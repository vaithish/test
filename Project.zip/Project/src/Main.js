import React, { Component } from 'react';

const values={"Karnataka":["","Bangalore","Mysore"],"Kerala":["","Palakad","Kochi","Uddupi"]};

export class App2 extends Component {

        constructor(props)
        {
                super(props);
                this.state={
                        state:'',
                        cities:'',
                        districtOptions:[],
                }
        }

        handleState = (event) => {
                this.setState({ districtOptions: values[event.target.value], state:event.target.value,cities: '' });
        }

        handleDistrict(value) {
                this.setState({ cities: value });
        }

    buttonClicked(event) {
	event.preventDefault();
        this.props.getEmployeeInfo(this.refs.fName.value,this.refs.lName.value,this.refs.states.value,this.refs.cities.value,this.refs.mail.value);
    }

        render() {

                var stateOptions = ['','Kerala','Karnataka'],
            stateOption = function(X) {
                return <option>{X}</option>;
            };
                var districtOptions = this.state.districtOptions,
                districtOption = function(X) {
                return <option>{X}</option>;
            };

                return (
				<div>
                 <form onSubmit={this.buttonClicked.bind(this)} >
                  <h2>Employee Information</h2>
                  <table>
                  <tr><td><label>FirstName :</label></td><td><input id="inputfName" type="text" ref="fName" /></td></tr>
				  <br/>
                  <tr><td><label>LastName :</label></td><td><input id="inputlNames" ref="lName" type="text" /></td></tr>
				  <br/>
                  <tr><td><label>State :</label></td><td>
                  <select  name="state" onChange={this.handleState} ref="states">{stateOptions.map(stateOption)}</select></td></tr>
				  <br/>

                  <tr><td><label>Districts  :</label></td><td>
                  <select  name="district" onchange={this.handleDistrict} ref="cities" >{districtOptions.map(districtOption)}</select></td></tr>
				  <br/>
                  <tr><td><label>Email :</label></td><td><input id="inputMail" type="text" ref="mail"/></td></tr>
				  <br/>
                  <button type="submit" >Submit</button>
                  </table>
                  </form>
				  <br/>
				  </div>
                );
    }
}