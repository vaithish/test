import React from 'react';
import ReactDOM from "react-dom";
import {Router,Route} from "react-router";
import Login from './login';
import App from './SecondMain';

ReactDOM.render(
<Router>
<Route path="/" component={Login}/>
<Route path="/nav" component={App} />
</Router>,
    document.getElementById('root')
);

