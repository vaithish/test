import React, {Component, PropTypes} from'react';
import {Link, Router, Route, hashHistory} from "react-router";


class Login extends React.Component{
static contextTypes = {
    router: PropTypes.object
  };
  
   constructor(props) {
    super(props);
    this.state = {
        username:'',
        password:'',
    };

    this.handleUserName = this.handleUserName.bind(this);
    this.handlePassword = this.handlePassword.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
    handleUserName(event) {
    this.setState({username: event.target.value});
  }

   handlePassword(event) {
    this.setState({password: event.target.value});
  }
    
    handleSubmit(event){
        event.preventDefault();
        const user="Kathir";
        const passwd="Kathir";
        console.log('inside submit');
        if(user===this.state.username && passwd===this.state.password)
        {
            
           this.context.router.push('/nav');
        }
    }

render(){
return(
<div className="login" align="center">
<center>
<h1>Login</h1>
<form className="loginForm" onSubmit={this.handleSubmit}>
<div className="form-group">
<input type="text" className="inp" value={this.state.username} onChange={this.handleUserName}/>
</div>
<div className="form-group">
<input type="password" className="inp" value={this.state.password} onChange={this.handlePassword}/>
</div>
<input type="submit" value="Submit" />
</form>
</center>
</div>
);
}
}


export default Login;