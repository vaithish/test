import React, { Component } from 'react';
import Person from './Rendering';
import {App2} from './Main';

class App extends Component {

constructor(props){
super(props);

this.state = {
  data : [
  {
            firstName: "Kathirvel",
            lastName: "Thirumani",
            state1: "TamilNadu",
            city: "Chennai",
            email: "Kathirvel.Thirumani@mindtree.com"
        }
  ],

title : ['FirstName' , 'LastName', 'Email']

}
}

getEmployee(fName,lName,states,cities,mail){ 
    var newRowData = this.state.data;
    newRowData.push({firstName:fName,lastName:lName,state1:states,city:cities,email:mail});
    this.setState({
      data:newRowData
  });
}

updateEmployee(index,fName,lName,mail){

  var tempData = this.state.data;

  for(var i = 0; i< tempData.length; i++){
    if (i == index){
      tempData[i].firstName=fName;
	  tempData[i].lastName=lName;
	  tempData[i].email=mail;
    }
  }

  this.setState({
    data: tempData
  });
}

deleteEmployee(index,fName,lName,mail){

  var tempData = this.state.data;

  for(var i = 0; i< tempData.length; i++){
    if (i == index){
      tempData.splice(index, 1);
  this.setState({data: tempData });
    }
  }
}

  render() {

  var persons = this.state.data.map((person,i) => 
      <Person prsn={person} index={i}
      updateEmployeeInfo = {this.updateEmployee.bind(this)}
      deleteEmployeeInfo = {this.deleteEmployee.bind(this)}
      />)
      

    return (
      <div>
        <App2 getEmployeeInfo = {this.getEmployee.bind(this)}/>         
        <table>
		   <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
		<th></th>
		<th></th>
      </tr>
    </thead>
	<tbody>
{persons}
	</tbody>
	</table>
      </div>
    );
  }
}


export default App;
