import React, { Component} from 'react';
import {App2} from './Main';

class Person extends Component {
	constructor(props){
	super(props);
		this.state={
			isEditMode: false
		}
	}

	EditModeON(){
		this.setState({
			isEditMode : true
		});

	}	

	buttonUpdate()
	{
		this.props.updateEmployeeInfo(this.props.index,this.refs.textName.value, this.refs.textLast.value, this.refs.textEmail.value);
		this.setState({
			isEditMode : false
		});
	}
	
	buttonDelete(){
		this.props.deleteEmployeeInfo(this.props.index,this.props.prsn.firstName, this.props.prsn.lastName, this.props.prsn.email);
	}
	
	render(){
		var displayMode = (
		<tr>
				<td>{this.props.prsn.firstName}</td>
				<td>{this.props.prsn.lastName}</td>
    			<td>{this.props.prsn.email}</td>
			    <td>
			      <button type="button" onClick={this.EditModeON.bind(this)}>Edit</button>
			    </td>
			    <td>
			      <button type="button" onClick={this.buttonDelete.bind(this)}>Delete</button>
			    </td>
		</tr>
		);

		var editMode = (
			    <div>
			    <tr>
					<td><input type="text" ref="textName" defaultValue={this.props.prsn.firstName} /></td>&nbsp;&nbsp;
					<td><input type="text" ref="textLast" defaultValue={this.props.prsn.lastName} /></td>&nbsp;&nbsp;
	    			<td><input type="text" ref="textEmail" style={{width:300}}  defaultValue={this.props.prsn.email} /></td>&nbsp;&nbsp;&nbsp;&nbsp;
				    <td><button type="button" className="btn btn-primary" onClick={this.buttonUpdate.bind(this)}>Update</button></td>
				</tr>
				</div>
		);

		return(
			this.state.isEditMode ? editMode : displayMode
		);
	}
}

export default Person;
